

<?php $__env->startSection('content'); ?>
<div class="row">
  <div class="col-xl-9 mx-auto">
    <h6 class="mb-0 text-uppercase">Control About Section</h6>
    <hr>
    <div class="card">
      <div class="card-body">
        <form action="<?php echo e(route('aboutUpdate')); ?>" method="POST" enctype="multipart/form-data">
          <?php echo csrf_field(); ?>
        <div class="border p-3 rounded">
          <div class="mb-3">
            <label class="form-label">Profile Image</label>
            <input type="file" class="form-control" name="image" id="Profileimg">
            <img id="showProfile" src="<?php echo e((!empty($about->image)) ? url($about->image):url('images/profile/no_image.jpeg')); ?>" style="width:100px; height: 100px;" >
          </div>
          <div class="mb-3">
            <label class="form-label">First Name</label>
            <input type="text" class="form-control" name="firstname" value="<?php echo e($about->firstname); ?>">
          </div>
          <div class="mb-3">
            <label class="form-label">Last Name</label>
            <input type="text" class="form-control" name="lastname" value="<?php echo e($about->lastname); ?>">
          </div>
          <div class="mb-3">
            <label class="form-label">email </label>
            <input type="email" class="form-control" name="email" value="<?php echo e($about->email); ?>">
          </div>
          <div class="mb-3">
            <label class="form-label">phone </label>
            <input type="number" class="form-control" name="phone" value="<?php echo e($about->phone); ?>">
          </div>
          <div class="mb-3">
            <label class="form-label">address </label>
            <input type="text" class="form-control" name="address" value="<?php echo e($about->address); ?>">
          </div>
          <div class="mb-3">
            <label class="form-label">Age </label>
            <input type="number" class="form-control" name="age" value="<?php echo e($about->age); ?>">
          </div>
          <div class="mb-3">
            <label class="form-label">Nationality</label>
            <input type="text" class="form-control" name="nationality" value="<?php echo e($about->nationality); ?>">
          </div>
          <div class="mb-3">
            <label class="form-label">Whatsapp</label>
            <input type="text" class="form-control" name="whatsapp" value="<?php echo e($about->whatsapp); ?>">
          </div>
          <div class="mb-3">
            <label class="form-label">Languages</label>
            <input type="text" class="form-control" name="languages" value="<?php echo e($about->languages); ?>">
          </div>
          <div class="mb-3">
            <label class="form-label">Work Year</label>
            <input type="text" class="form-control" name="work_year" value="<?php echo e($about->work_year); ?>">
          </div>
          <div class="mb-3">
            <label class="form-label">Freelance</label>
            <input type="text" class="form-control" name="freelance" value="<?php echo e($about->freelance); ?>">
          </div>
          <div class="mb-3">
            <button type="submit" class="btn btn-primary" >Update</button>
          </div>
        </div>
        </form>
      </div>
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
<script type="text/javascript">
	$(document).ready(function(){
		$('#Profileimg').change(function(e){
			var reader = new FileReader();
			reader.onload = function(e){
				$('#showProfile').attr('src',e.target.result);
			}
			reader.readAsDataURL(e.target.files['0']);
		});

	});
</script>
<?php $__env->stopPush(); ?>


<?php echo $__env->make('backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\Laravel-Protfolio-site\resources\views/backend/pages/about/about.blade.php ENDPATH**/ ?>