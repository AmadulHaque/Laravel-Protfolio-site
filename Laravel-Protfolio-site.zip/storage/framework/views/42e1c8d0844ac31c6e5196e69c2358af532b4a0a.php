        <!-- Start about section -->
        <section class="about__section about__section--bg section--padding" id="about">
            <div class="container">
                <div class="about__section--inner d-flex">
                    <div class="about__content">
                        <div class="section__heading mb-30">
                            <span class="section__heading--subtitle text__secondary">ABOUT ME</span>
                            <h2 class="section__heading--title"><?php echo e($setting->a_title); ?></h2> 
                        </div>
                        <div class="about__info">
                            <h3 class="about__info--title text__secondary mb-20">PERSONAL INFOS:</h3>
                            <ul class="about__info--wrapper d-flex">
                                <li class="about__info--items">First Name: <?php echo e($about->firstname); ?></li>
                                <li class="about__info--items">Last Name: <?php echo e($about->lastname); ?></li>
                                <li class="about__info--items">Address: <?php echo e($about->address); ?></li>
                                <li class="about__info--items">Phone: <?php echo e($about->phone); ?></li>
                                <li class="about__info--items">Age: <?php echo e($about->age); ?></li>
                                <li class="about__info--items">Email: <?php echo e($about->email); ?></li>
                                <li class="about__info--items">Nationality: <?php echo e($about->nationality); ?></li>
                                <li class="about__info--items">whatsapp: <?php echo e($about->whatsapp); ?></li>
                                <li class="about__info--items">Freelance: <?php echo e($about->firstname ? $about->firstname : "Not Available"); ?></li>
                                <li class="about__info--items">Languages: <?php echo e($about->languages); ?></li>
                            </ul>
                            <a class="about__btn primary__btn" href="#">Hire Me</a>
                        </div>
                    </div>
                    <div class="about__thumbnail">
                        <div class=" position__relative">
                            <img class="position__relative" src="<?php echo e($about->image); ?>" alt="img">
                        </div>
                        <div class="about__experience text-center">
                            <h4 class="about__experience--title title-stroke"><?php echo e($about->work_year); ?>+ Year </h4>
                            <span class="about__experience--subtitle">Experience Working</span>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- End about section -->

        <!-- Start skills Section -->
        <section class="skills__section section--padding pt-5">
            <div class="container pt-5">
                <div class="section__heading--topbar d-flex align-items-center justify-content-between mb-50">
                    <div class="section__heading max-width-580">
                        <span class="section__heading--subtitle text__secondary">SKILLs</span>
                        <h2 class="section__heading--title"><?php echo e($setting->sk_title); ?></h2> 
                    </div>
                    <div class="section__heading--right max-width-450">
                        <p class="section__heading--desc"><?php echo e($setting->sk_desc); ?></p>
                    </div>
                </div>
                <div class="skills__section--inner d-flex justify-content-between">
                    <div class="skills__step">
                        <?php $__currentLoopData = $skillF; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="skills__items">
                                <div class="skills__text">
                                    <span class="skills__name"><?php echo e($item->name); ?></span>
                                    <span class="skills__count width_100"><?php echo e($item->number==0 ? "N/A" : $item->number); ?></span>
                                </div>
                                <div class="skills__field width_100">
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div class="skills__step">
                        <?php $__currentLoopData = $skillB; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="skills__items">
                                <div class="skills__text">
                                    <span class="skills__name"><?php echo e($item->name); ?></span>
                                    <span class="skills__count width_100"><?php echo e($item->number==0 ? "N/A" : $item->number); ?></span>
                                </div>
                                <div class="skills__field width_100">
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </section>
        <!-- End skills Section -->





        <?php /**PATH C:\xampp\htdocs\laravel\Laravel-Protfolio-site\resources\views/frontend/pages/about.blade.php ENDPATH**/ ?>