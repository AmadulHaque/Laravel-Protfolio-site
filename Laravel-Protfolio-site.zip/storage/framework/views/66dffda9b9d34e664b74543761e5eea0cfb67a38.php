

<?php $__env->startSection('content'); ?>
<div class="row">
  <div class="col-xl-9 mx-auto">
    <h6 class="mb-0 text-uppercase">Edit Portfolio Type </h6>
    <hr>
    <div class="card">
      <div class="card-body">
        <form action="<?php echo e(route('PortfolioTypeUpdate')); ?>" method="POST" enctype="multipart/form-data">
          <?php echo csrf_field(); ?>
          <input type="hidden" name="id" value="<?php echo e($data->id); ?>">
            <div class="border p-3 rounded">
              <div class="mb-3">
                <label class="form-label">Portfolio Type Title</label>
                <input type="text" required class="form-control" name="title" value="<?php echo e($data->title); ?>" >
              </div>
              <div class="mb-3">
                <select name="status" class="form-control" required id="">
                    <option <?php if($data->status==1): ?> selected <?php endif; ?>  value="1">Active</option>
                    <option <?php if($data->status==0): ?> selected <?php endif; ?>  value="0">InActive</option>
                </select>
              </div>
              <div class="mb-3">
                <button type="submit" class="btn btn-primary" >Submit</button>
              </div>
            </div>
        </form>
      </div>
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\Laravel-Protfolio-site\resources\views/backend/pages/PortfolioType/edit.blade.php ENDPATH**/ ?>