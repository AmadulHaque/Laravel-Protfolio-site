
<?php $__env->startSection('content'); ?>
<?php
$setting =DB::table('settings')->first();
?>
    <!-- end page title -->
    <div class="row">
      <div class="col-12">
        <div class="card">
          <div id="printableArea" class="card-body">
            <div class="row">
              <div class="col-12">
                <div class="invoice-title">
                  <h3>   <img src="<?php echo e((!empty($setting->logo)) ? url('images/setting/'.$setting->logo):url('images/profile/no_image.jpeg')); ?>" class="logo-icon" height="24" alt="logo icon"></h3>
                </div>
                <hr>
                <div class="row">
                  <div class="col-6 mt-4">
                    <address>
                      <strong><?php echo e($setting->shop_title); ?> Shopping Mall:</strong>
                      <br><?php echo e($setting->address); ?><br> <?php echo e($setting->email); ?>

                    </address>
                  </div>
                  <div class="col-6 mt-4 text-end">
                    <address></address>
                  </div>
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-12">
                <div>
                  <div class="p-2"></div>
                  <div class="">
                    <div class="table-responsive">
                      <table class="table">
                        <thead>
                          <tr>
                            <td>
                              <strong>Sl </strong>
                            </td>
                            <td class="text-center">
                              <strong>Customer Name </strong>
                            </td>
                            <td class="text-center">
                              <strong>Invoice No </strong>
                            </td>
                            <td class="text-center">
                              <strong>Date</strong>
                            </td>
                            <td class="text-center">
                              <strong>Due Amount </strong>
                            </td>
                          </tr>
                        </thead>
                        <tbody>
                          <!-- foreach ($order->lineItems as $line) or some such thing here --> <?php $total_due = '0'; ?> <?php $__currentLoopData = $allData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <tr>
                            <td class="text-center"> <?php echo e($key+1); ?> </td>
                            <td class="text-center"> <?php echo e($item['customer']['name']); ?> </td>
                            <td class="text-center"> #<?php echo e($item['invoice']['invoice_no']); ?> </td>
                            <td class="text-center"> <?php echo e(date('d-m-Y',strtotime($item['invoice']['date']))); ?> </td>
                            <td class="text-center"> <?php echo e($item->due_amount); ?> </td>
                          </tr> <?php $total_due += $item->due_amount; ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <tr>
                            <td class="no-line"></td>
                            <td class="no-line"></td>
                            <td class="no-line"></td>
                            <td class="no-line text-center">
                              <strong>Grand Due Amount</strong>
                            </td>
                            <td class="no-line text-end">
                              <h4 class="m-0">$<?php echo e($total_due); ?></h4>
                            </td>
                          </tr>
                        </tbody>
                      </table>
                    </div> <?php $date = new DateTime('now', new DateTimeZone('Asia/Dhaka')); ?> <i>Printing Time : <?php echo e($date->format('F j, Y, g:i a')); ?></i>
                    <div class="d-print-none">
                      <div class="float-end">
                        <a href="#" onclick="printDiv()" class="printdiv btn btn-danger waves-effect waves-light ms-2"><i class="lni lni-printer"></i></a>

                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <!-- end row -->
          </div>
        </div>
      </div>
      <!-- end col -->
    </div>
    <!-- end row -->



    <script type="text/javascript">
    function printDiv() {

      var divName= "printableArea";

       var printContents = document.getElementById(divName).innerHTML;
       var originalContents = document.body.innerHTML;

       document.body.innerHTML = printContents;

       window.print();

       document.body.innerHTML = originalContents;
    }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel10-inventory-version-php8.2.2\resources\views/backend/pages/pdf/customer_paid_pdf.blade.php ENDPATH**/ ?>