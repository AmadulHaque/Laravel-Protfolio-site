
<?php $__env->startSection('content'); ?>

<div  class=" row">
  <div class="col-12">
    <div id="printableArea" class="card">
      <div  class="card-body">
        <div class="row">
          <div class="col-12">
            <div class="invoice-title">
              <h4 class="float-end font-size-16">
                <strong>Invoice No # <?php echo e($invoice->invoice_no); ?></strong>
              </h4>
              <h3>
                <img src="<?php echo e((!empty($setting->logo)) ? url('images/setting/'.$setting->logo):url('images/profile/no_image.jpeg')); ?>" alt="logo" height="24" />
              </h3>
            </div>
            <hr>
            <div class="row">
              <div class="col-6 mt-4">
                    <address>
                      <strong><?php echo e($setting->shop_title); ?> Shopping Mall:</strong>
                      <br><?php echo e($setting->address); ?><br> <?php echo e($setting->email); ?>

                    </address>
              </div>
              <div class="col-6 mt-4 text-end">
                <address>
                  <strong>Invoice Date:</strong>
                  <br>
                  <?php echo e(date('d-m-Y',strtotime($invoice->date))); ?>

                  <br>
                  <br>
                </address>
              </div>
            </div>
          </div>
        </div> <?php $payment = App\Models\Payment::where('invoice_id',$invoice->id)->first(); ?> <div class="row">
          <div class="col-12">
            <div>
              <div class="p-2">
                <h3 class="font-size-16">
                  <strong>Customer Invoice</strong>
                </h3>
              </div>
              <div class="">
                <div class="table-responsive">
                  <table class="table  table-striped table-bordered ">
                    <thead>
                      <tr>
                        <td>
                          <strong>Customer Name </strong>
                        </td>
                        <td class="text-center">
                          <strong>Customer Mobile</strong>
                        </td>
                        <td class="text-center">
                          <strong>Address</strong>
                        </td>
                        <td class="text-center">
                          <strong>Description</strong>
                        </td>
                      </tr>
                    </thead>
                    <tbody>
                      <!-- foreach ($order->lineItems as $line) or some such thing here -->
                      <tr>
                        <td> <?php echo e($payment['customer']['name']); ?></td>
                        <td class="text-center"><?php echo e($payment['customer']['mobile_no']); ?></td>
                        <td class="text-center"><?php echo e($payment['customer']['email']); ?></td>
                        <td class="text-center"><?php echo e($invoice->description); ?></td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- end row -->
        <div class="row">
          <div class="col-12">
            <div>
              <div class="p-2"></div>
              <div class="">
                <div class="">
                  <table class="table table-condensed table-striped table-bordered ">
                    <thead>
                      <tr>
                        <td>
                          <strong>Sl </strong>
                        </td>
                        <td class="text-center">
                          <strong>Category</strong>
                        </td>
                        <td class="text-center">
                          <strong>Product Name</strong>
                        </td>
                        <td class="text-center">
                          <strong>Current Stock</strong>
                        </td>
                        <td class="text-center">
                          <strong>Quantity</strong>
                        </td>
                        <td class="text-center">
                          <strong>Unit Price </strong>
                        </td>
                        <td class="text-center">
                          <strong>Total Price</strong>
                        </td>
                      </tr>
                    </thead>
                    <tbody>
                      <!-- foreach ($order->lineItems as $line) or some such thing here --> <?php $total_sum = '0'; ?> <?php $__currentLoopData = $invoice['invoice_details']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $details): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <tr>
                        <td class="text-center"><?php echo e($key+1); ?></td>
                        <td class="text-center"><?php echo e($details['category']['name']); ?></td>
                        <td class="text-center"><?php echo e($details['product']['name']); ?></td>
                        <td class="text-center"><?php echo e($details['product']['quantity']); ?></td>
                        <td class="text-center"><?php echo e($details->selling_qty); ?></td>
                        <td class="text-center"><?php echo e($details->unit_price); ?></td>
                        <td class="text-center"><?php echo e($details->selling_price); ?></td>
                      </tr> <?php $total_sum += $details->selling_price; ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <tr>
                        <td class="thick-line"></td>
                        <td class="thick-line"></td>
                        <td class="thick-line"></td>
                        <td class="thick-line"></td>
                        <td class="thick-line"></td>
                        <td class="thick-line text-center">
                          <strong>Subtotal</strong>
                        </td>
                        <td class="thick-line text-end">$<?php echo e($total_sum); ?></td>
                      </tr>
                      <tr>
                        <td class="no-line"></td>
                        <td class="no-line"></td>
                        <td class="no-line"></td>
                        <td class="no-line"></td>
                        <td class="no-line"></td>
                        <td class="no-line text-center">
                          <strong>Discount Amount</strong>
                        </td>
                        <td class="no-line text-end">$<?php echo e($payment->discount_amount); ?></td>
                      </tr>
                      <tr>
                        <td class="no-line"></td>
                        <td class="no-line"></td>
                        <td class="no-line"></td>
                        <td class="no-line"></td>
                        <td class="no-line"></td>
                        <td class="no-line text-center">
                          <strong>Paid Amount</strong>
                        </td>
                        <td class="no-line text-end">$<?php echo e($payment->paid_amount); ?></td>
                      </tr>
                      <tr>
                        <td class="no-line"></td>
                        <td class="no-line"></td>
                        <td class="no-line"></td>
                        <td class="no-line"></td>
                        <td class="no-line"></td>
                        <td class="no-line text-center">
                          <strong>Due Amount</strong>
                        </td>
                        <td class="no-line text-end">$<?php echo e($payment->due_amount); ?></td>
                      </tr>
                      <tr>
                        <td class="no-line"></td>
                        <td class="no-line"></td>
                        <td class="no-line"></td>
                        <td class="no-line"></td>
                        <td class="no-line"></td>
                        <td class="no-line text-center">
                          <strong>Grand Amount</strong>
                        </td>
                        <td class="no-line text-end">
                          <h4 class="m-0">$<?php echo e($payment->total_amount); ?></h4>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </div>
                <div class="d-print-none">
                  <div class="float-end">
                    <a href="#" onclick="printDiv()" class="printdiv btn btn-danger waves-effect waves-light ms-2"><i class="lni lni-printer"></i></a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- end row -->
      </div>
    </div>
  </div>
  <!-- end col -->
</div>
<!-- end row -->
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>


<script type="text/javascript">
function printDiv() {

  var divName= "printableArea";

   var printContents = document.getElementById(divName).innerHTML;
   var originalContents = document.body.innerHTML;

   document.body.innerHTML = printContents;

   window.print();

   document.body.innerHTML = originalContents;
}
</script>




<?php $__env->stopPush(); ?>

<?php echo $__env->make('backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel10-inventory-version-php8.2.2\resources\views/backend/pages/pdf/invoice_pdf.blade.php ENDPATH**/ ?>