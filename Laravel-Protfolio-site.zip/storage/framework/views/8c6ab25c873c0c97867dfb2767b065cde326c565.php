<!-- Modal -->
<div class="modal fade" id="addProductModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Add Product</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <form method="post" id="addProductStore">
          <?php echo csrf_field(); ?>
          <div class="modal-body">

            <div class="row mb-3">
              <label for="example-text-input" class="col-sm-2 col-form-label">Product Name </label>
              <div class="form-group col-sm-10">
                <input name="name" class="form-control" type="text">
              </div>
            </div>
            <!-- end row -->
            <div class="row mb-3">
              <label class="col-sm-2 col-form-label">Supplier Name </label>
              <div class="col-sm-10">
                <select name="supplier_id" class="form-select" aria-label="Default select example">
                  <option selected="" value="">Open this select menu</option>
                   <?php $__currentLoopData = $supplier; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($supp->id); ?>"><?php echo e($supp->name); ?></option>
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>
            </div>
            <!-- end row -->
            <div class="row mb-3">
              <label class="col-sm-2 col-form-label">Unit Name </label>
              <div class="col-sm-10">
                <select name="unit_id" class="form-select" aria-label="Default select example">
                  <option selected="" value="">Open this select menu</option>
                   <?php $__currentLoopData = $unit; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $uni): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($uni->id); ?>"><?php echo e($uni->name); ?></option>
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>
            </div>
            <!-- end row -->
            <div class="row mb-3">
              <label class="col-sm-2 col-form-label">Category Name </label>
              <div class="col-sm-10">
                <select name="category_id" class="form-select" aria-label="Default select example">
                  <option selected="" value="" >Open this select menu</option>
                  <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($cat->id); ?>"><?php echo e($cat->name); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>
            </div>

            <div class="row mb-3">
              <label class="col-sm-2 col-form-label">Brand Name </label>
              <div class="col-sm-10">
                <select name="brand_id" class="form-select" aria-label="Default select example">
                  <option selected="" value="" >Open this select menu</option>
                  <?php $__currentLoopData = $brand; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($cat->id); ?>"><?php echo e($cat->name); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>
            </div>

            <!-- end row -->
            <div class="row mb-3">
              <label for="example-text-input" class="col-sm-2 col-form-label">Thumbnail Image </label>
              <div class="form-group col-sm-10">
                <input name="image" class="form-control" type="file" id="image">
              </div>
            </div>
            <!-- end row -->
            <div class="row mb-3">
              <label for="example-text-input" class="col-sm-2 col-form-label"></label>
              <div class="col-sm-10">
                <img id="showImage" style="width:50%" class="rounded avatar-lg" src="<?php echo e(url('images/no_image.jpeg')); ?>" alt="Card image cap">
              </div>
            </div>
            <!-- end row -->
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-primary">Add Product</button>
          </div>
      </form>
    </div>
  </div>
</div>
<?php /**PATH C:\xampp\htdocs\lb-inventory\resources\views/backend/components/purchase/add.blade.php ENDPATH**/ ?>