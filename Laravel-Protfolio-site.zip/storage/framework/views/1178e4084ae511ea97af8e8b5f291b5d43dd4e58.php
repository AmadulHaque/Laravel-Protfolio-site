

<?php $__env->startSection('content'); ?>
<div class="row">
  <div class="col-xl-9 mx-auto">
    <h6 class="mb-0 text-uppercase">Control Hero Section</h6>
    <hr>
    <div class="card">
      <div class="card-body">
        <form action="<?php echo e(route('updateHeroSec')); ?>" method="POST" enctype="multipart/form-data">
          <?php echo csrf_field(); ?>
        <div class="border p-3 rounded">
          <div class="mb-3">
            <label class="form-label">Profile Image</label>
            <input type="file" class="form-control" name="image" id="Profileimg">
            <img id="showProfile" src="<?php echo e((!empty($hero->image)) ? url('images/profile/'.$hero->image):url('images/profile/no_image.jpeg')); ?>" style="width:100px; height: 100px;" >
          </div>
          <div class="mb-3">
            <label class="form-label">Frontend  Icon</label>
            <input type="file" class="form-control" name="frontimage" id="frontimageImg">
            <img id="showfrontimage" src="<?php echo e((!empty($hero->frontimage)) ? url('images/profile/'.$hero->frontimage):url('images/profile/no_image.jpeg')); ?>" style="width:100px; height: 100px;" >
          </div>
          <div class="mb-3">
            <label class="form-label">Backend  Icon</label>
            <input type="file" class="form-control" name="backimage" id="backimageImg">
            <img id="showbackimage" src="<?php echo e((!empty($hero->backimage)) ? url('images/profile/'.$hero->backimage):url('images/profile/no_image.jpeg')); ?>" style="width:100px; height: 100px;" >
          </div>
          <div class="mb-3">
            <label class="form-label">Head Title</label>
            <input type="text" class="form-control" name="head" value="<?php echo e($hero->head); ?>">
          </div>
          <div class="mb-3">
            <label class="form-label">Name</label>
            <input type="text" class="form-control" name="name" value="<?php echo e($hero->name); ?>">
          </div>
          <div class="mb-3">
            <label class="form-label">Designation </label>
            <input type="text" class="form-control" name="designation" value="<?php echo e($hero->designation); ?>">
          </div>
          <div class="mb-3">
            <label class="form-label">Title </label>
            <input type="text" class="form-control" name="title" value="<?php echo e($hero->title); ?>">
          </div>
          <div class="mb-3">
            <label class="form-label">Project </label>
            <input type="text" class="form-control" name="project" value="<?php echo e($hero->project); ?>">
          </div>
          <div class="mb-3">
            <label class="form-label">Github</label>
            <input type="text" class="form-control" name="github" value="<?php echo e($hero->github); ?>">
          </div>
          <div class="mb-3">
            <label class="form-label">Facebook</label>
            <input type="text" class="form-control" name="fb" value="<?php echo e($hero->fb); ?>">
          </div>
          <div class="mb-3">
            <label class="form-label">Linkdin</label>
            <input type="text" class="form-control" name="linkdin" value="<?php echo e($hero->linkdin); ?>">
          </div>
          <div class="mb-3">
            <label class="form-label">Youtube</label>
            <input type="text" class="form-control" name="youtube" value="<?php echo e($hero->youtube); ?>">
          </div>
          <div class="mb-3">
            <button type="submit" class="btn btn-primary" >Update</button>
          </div>
        </div>
        </form>
      </div>
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
<script type="text/javascript">
	$(document).ready(function(){

		$('#Profileimg').change(function(e){
			var reader = new FileReader();
			reader.onload = function(e){
				$('#showProfile').attr('src',e.target.result);
			}
			reader.readAsDataURL(e.target.files['0']);
		});

	});
</script>
<script type="text/javascript">
  $(document).ready(function(){
    $('#frontimageImg').change(function(e){
      var reader = new FileReader();
      reader.onload = function(e){
        $('#showfrontimage').attr('src',e.target.result);
      }
      reader.readAsDataURL(e.target.files['0']);
    });

    $('#backimageImg').change(function(e){
      var reader = new FileReader();
      reader.onload = function(e){
        $('#showbackimage').attr('src',e.target.result);
      }
      reader.readAsDataURL(e.target.files['0']);
    });

  });
</script>
<?php $__env->stopPush(); ?>


<?php echo $__env->make('backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\Laravel-Protfolio-site\resources\views/backend/pages/heroSection/index.blade.php ENDPATH**/ ?>