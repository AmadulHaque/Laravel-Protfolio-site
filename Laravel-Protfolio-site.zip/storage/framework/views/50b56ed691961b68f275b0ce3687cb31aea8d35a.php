

<?php $__env->startSection('content'); ?>
<?php
      $types = DB::table('port_types')->where('status',1)->get();
?>
<div class="row">
  <div class="col-xl-9 mx-auto">
    <h6 class="mb-0 text-uppercase">Add Portfolio Type</h6>
    <hr>
    <div class="card">
      <div class="card-body">
        <form action="<?php echo e(route('PortfolioPost')); ?>" method="POST" enctype="multipart/form-data">
          <?php echo csrf_field(); ?>
            <div class="border p-3 rounded">
              <div class="mb-3">
                <label class="form-label">Portfolio Type </label>
                <select name="type_id" class="form-control" required id="">
                    <option value="">--select--</option>
                    <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($item->id); ?>"><?php echo e($item->title); ?></option> 
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>
              <div class="mb-3">
                <label class="form-label">Title</label>
                <input type="text" required class="form-control" name="title" >
              </div>

              <div class="mb-3">
                <label class="form-label">Description</label>
                <textarea name="desc"  class="form-control"></textarea>
              </div>

              <div class="mb-3">
                <label class="form-label">Image</label>
                <input type="file" required class="form-control" name="image">
              </div>

              <div class="mb-3">
                <label class="form-label">Project</label>
                <input type="text" required class="form-control" name="project" >
              </div>

              <div class="mb-3">
                <label class="form-label">Languages</label>
                <input type="text" required class="form-control" name="languages" >
              </div>

              <div class="mb-3">
                <label class="form-label">Client</label>
                <input type="text" required class="form-control" name="client" >
              </div>

              <div class="mb-3">
                <label class="form-label">Preview Link</label>
                <input type="text" required class="form-control" name="preview" >
              </div>



              <div class="mb-3">
                <select name="status" class="form-control" required id="">
                    <option value="1">Active</option>
                    <option value="0">InActive</option>
                </select>
              </div>
          
              <div class="mb-3">
                <button type="submit" class="btn btn-primary" >Submit</button>
              </div>
            </div>
        </form>
      </div>
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\Laravel-Protfolio-site\resources\views/backend/pages/Portfolio/add.blade.php ENDPATH**/ ?>