<div class="table-bottom-wrapper">
    <div class="out-of-showing">
        <p><?php echo e($paginate->firstItem()); ?> - <?php echo e($paginate->lastItem()); ?> of <?php echo e($paginate->total()); ?> (for page <?php echo e($paginate->currentPage()); ?> )</p>
    </div>
    <div class="pagination-wraper">
        <nav aria-label="...">
            <?php echo $paginate->links(); ?>

        </nav>

    </div>
</div>
<?php /**PATH /home/tsalvoja/public_html/resources/views/backend/partials/pagination.blade.php ENDPATH**/ ?>