
  <input type="hidden" name="id" value="<?php echo e($data->id); ?>">
  <div class="row mb-3">
    <label for="example-text-input" class="col-sm-2 col-form-label">Brand Name </label>
    <div class="form-group col-sm-10">
      <input name="name" class="form-control" type="text" value="<?php echo e($data->name); ?>">
    </div>
  </div>
  
<?php /**PATH C:\xampp\htdocs\lb-inventory\resources\views/backend/components/brand/edit.blade.php ENDPATH**/ ?>