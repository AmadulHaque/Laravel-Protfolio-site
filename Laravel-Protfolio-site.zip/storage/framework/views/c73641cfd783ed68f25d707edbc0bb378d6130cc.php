

<table id="example" class="table table-striped table-bordered" style="width:100%">
  <thead>
    <tr>
      <th>Sl</th>
      <th>Name</th>
      <th>Action</th>
    </tr>
  </thead>
  <tbody>
    <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <td> <?php echo e($key+1); ?> </td>
      <td> <?php echo e($item->name); ?> </td>
      <td>
        <div class="col">
          <button type="button" class="btn btn-outline-success btn-sm edit_row" id_val="<?php echo e($item->id); ?>"><i class="fadeIn animated bx bx-message-square-edit"></i></button>
          <button type="button" class="btn btn-outline-danger btn-sm delete_row" id_val="<?php echo e($item->id); ?>" ><i class="lni lni-trash"></i></button>
        </div>
      </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>
<?php if(count($datas) == 0): ?>
   <tr><p class="text-center p-5">No Data Found</p></tr>
<?php endif; ?>


<?php $paginate = $datas ?>
<?php echo $__env->make( 'backend.partials.pagination', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\xampp\htdocs\Laravel10-inventory-version-php8.2.2\resources\views/backend/components/ExpenseType/table.blade.php ENDPATH**/ ?>