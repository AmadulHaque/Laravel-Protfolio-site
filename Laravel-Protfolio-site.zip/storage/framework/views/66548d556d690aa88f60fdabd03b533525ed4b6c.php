

<?php $__env->startSection('content'); ?>
<?php
$setting =DB::table('settings')->first();
?>
<div class="row">
  <div class="col-xl-9 mx-auto">
    <h6 class="mb-0 text-uppercase">Control Setting</h6>
    <hr>
    <div class="card">
      <div class="card-body">
        <form action="<?php echo e(route('updateSetting')); ?>" method="POST" enctype="multipart/form-data">
          <?php echo csrf_field(); ?>
          <div class="border p-3 rounded">
            <div class="mb-3">
              <label class="form-label">Logo Image</label>
              <input type="file" class="form-control" name="logo_img" id="Logoimg">
              <img id="showlogo" src="<?php echo e((!empty($setting->logo)) ? url('images/setting/'.$setting->logo):url('images/profile/no_image.jpeg')); ?>" style="width:100px; height: 100px;" >
            </div>
            <div class="mb-3">
              <label class="form-label">Favicon Image</label>
              <input type="file" class="form-control" name="favicon" id="faviconImg">
              <img id="showFavicon" src="<?php echo e((!empty($setting->favicon)) ? url('images/setting/'.$setting->favicon):url('images/profile/no_image.jpeg')); ?>" style="width:100px; height: 100px;" >
            </div>
            <div class="mb-3">
              <label class="form-label">Email</label>
              <input type="text" class="form-control" name="email" value="<?php echo e($setting->email); ?>">
            </div>
            <div class="mb-3">
              <label class="form-label">Phone </label>
              <input type="text" class="form-control" name="phone" value="<?php echo e($setting->phone); ?>">
            </div>
            <div class="mb-3">
              <label class="form-label">Title </label>
              <input type="text" class="form-control" name="title" value="<?php echo e($setting->title); ?>">
            </div>
          </div>

          <div class="border p-3 rounded mt-4">
            <h2 class="text-center">Service </h2>
            <div class="mb-3">
              <label class="form-label">Title </label>
              <input type="text" class="form-control" name="s_title" value="<?php echo e($setting->s_title); ?>">
            </div>
            <div class="mb-3">
              <label class="form-label">Description</label>
              <textarea name="s_desc" class="form-control" >
                <?php echo e($setting->s_desc); ?>

              </textarea>
            </div>
          </div>
          
          <div class="border p-3 rounded mt-4">
            <h2 class="text-center">About </h2>
            <div class="mb-3">
              <label class="form-label">About Title </label>
              <input type="text" class="form-control" name="a_title" value="<?php echo e($setting->a_title); ?>">
            </div>
            <hr>
            <div class="mb-3">
              <label class="form-label">Skill Title </label>
              <input type="text" class="form-control" name="sk_title" value="<?php echo e($setting->sk_title); ?>">
            </div>
            <div class="mb-3">
              <label class="form-label">Skill Description</label>
              <textarea name="sk_desc" class="form-control" >
                <?php echo e($setting->sk_desc); ?>

              </textarea>
            </div>
          </div>
          
          <div class="border p-3 rounded mt-4">
            <h2 class="text-center">Portfolio </h2>
            <div class="mb-3">
              <label class="form-label">Portfolio Title </label>
              <input type="text" class="form-control" name="p_title" value="<?php echo e($setting->p_title); ?>">
            </div>
            <hr>
            <div class="mb-3">
              <label class="form-label">Portfolio Description</label>
              <textarea name="p_desc" class="form-control" >
                <?php echo e($setting->p_desc); ?>

              </textarea>
            </div>
          </div>
          




          <div class="border p-3 rounded mt-2">
            <div class="mb-3">
              <button type="submit" class="btn btn-primary" >Update</button>
            </div>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
<script type="text/javascript">
	$(document).ready(function(){

		$('#Logoimg').change(function(e){
			var reader = new FileReader();
			reader.onload = function(e){
				$('#showlogo').attr('src',e.target.result);
			}
			reader.readAsDataURL(e.target.files['0']);
		});

	});
</script>
<script type="text/javascript">
  $(document).ready(function(){
    $('#faviconImg').change(function(e){
      var reader = new FileReader();
      reader.onload = function(e){
        $('#showFavicon').attr('src',e.target.result);
      }
      reader.readAsDataURL(e.target.files['0']);
    });

  });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\Laravel-Protfolio-site\resources\views/backend/pages/setting/index.blade.php ENDPATH**/ ?>