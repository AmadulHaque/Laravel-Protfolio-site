
<?php $__env->startSection('content'); ?>
	<?php
	$setting =DB::table('settings')->first();
	?>
	<!--start row-->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\Laravel-Protfolio-site\resources\views/backend/index.blade.php ENDPATH**/ ?>