

<table id="example" class="table table-striped table-bordered" style="width:100%">
  <thead>
    <tr>
        <th>Sl</th>
        <th>Customer Name</th> 
        <th>Invoice No </th>
        <th>Date</th>
        <th>Due Amount</th> 
        <th>Action</th>
    </tr>
  </thead>
  <tbody>
    <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td> <?php echo e($key+1); ?> </td>
        <td> <?php echo e($item['customer']['name']); ?> </td> 
        <td> <?php echo e($item['invoice']['invoice_no']); ?></td> 
        <td> <?php echo e(date('d-m-Y',strtotime($item['invoice']['date']))); ?> </td> 
        <td> <?php echo e($item->due_amount); ?> </td> 
        <td><a href="<?php echo e(route('customer.invoice.details.pdf',$item->invoice_id)); ?>" class="btn btn-info btn-sm" title="Edit Data"> <i class="lni lni-eye"></i> </a></td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>
<?php if(count($datas) == 0): ?>
   <tr><p class="text-center p-5">No Data Found</p></tr>
<?php endif; ?>


<?php $paginate = $datas ?>
<?php echo $__env->make( 'backend.partials.pagination', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\xampp\htdocs\lb-inventory\resources\views/backend/components/customer/paid_table.blade.php ENDPATH**/ ?>