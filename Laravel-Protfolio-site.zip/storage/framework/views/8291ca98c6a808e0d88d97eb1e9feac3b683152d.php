
  <input type="hidden" name="id" value="<?php echo e($data->id); ?>">
  <div class="row mb-3">
    <label for="example-text-input" class="col-sm-2 col-form-label">Category Name </label>
    <div class="form-group col-sm-10">
      <input name="name" class="form-control" type="text" value="<?php echo e($data->name); ?>">
    </div>
  </div>
  
<?php /**PATH C:\xampp\htdocs\Laravel10-inventory-version-php8.2.2\resources\views/backend/components/category/edit.blade.php ENDPATH**/ ?>