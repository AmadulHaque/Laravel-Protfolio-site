

<table id="example" class="table table-striped table-bordered" style="width:100%">
  <thead>
    <tr>
        <th>Sl</th>
        <th>Supplier Name </th>
        <th>Unit</th>
        <th>Category</th> 
        <th>Product Name</th> 
        <th>In Qty</th> 
        <th>Out Qty </th>  
        <th>Stock </th>
    </tr>
  </thead>
  <tbody>
    <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php
        $buying_total = App\Models\Purchase::where('category_id',$item->category_id)->where('product_id',$item->id)->where('status','1')->sum('buying_qty');
        $selling_total = App\Models\InvoiceDetail::where('category_id',$item->category_id)->where('product_id',$item->id)->where('status','1')->sum('selling_qty');
    ?>
    <tr>
      <td> <?php echo e($key+1); ?> </td> 
        <td> <?php echo e($item['supplier']['name']); ?> </td> 
        <td> <?php echo e($item['unit']['name']); ?> </td> 
        <td> <?php echo e($item['category']['name']); ?> </td> 
        <td> <?php echo e($item->name); ?> </td> 
        <td> <span class="btn btn-success"> <?php echo e($buying_total); ?></span>  </td> 
        <td> <span class="btn btn-info"> <?php echo e($selling_total); ?></span> </td> 
        <td> <span class="btn btn-danger"> <?php echo e($item->quantity); ?></span> </td> 
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>
<?php if(count($datas) == 0): ?>
   <tr><p class="text-center p-5">No Data Found</p></tr>
<?php endif; ?>


<?php $paginate = $datas ?>
<?php echo $__env->make( 'backend.partials.pagination', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\xampp\htdocs\lb-inventory\resources\views/backend/components/stock/table.blade.php ENDPATH**/ ?>