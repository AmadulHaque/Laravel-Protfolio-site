

<table id="example" class="table table-striped table-bordered" style="width:100%">
  <thead>
    <tr>
      <th>Sl</th>
      <th>Customer Name</th>
      <th>Invoice No </th>
      <th>Date </th>
      <th>Desctipion</th>
      <th>Amount</th>
    </tr>
  </thead>
  <tbody>
    <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td> <?php echo e($key+1); ?> </td>
        <td> <?php echo e($item['payment']['customer']['name']); ?> </td>
        <td> #<?php echo e($item->invoice_no); ?> </td>
        <td> <?php echo e(date('d-m-Y',strtotime($item->date))); ?> </td>
        <td>  <?php echo e($item->description); ?> </td>
        <td>  $ <?php echo e($item['payment']['total_amount']); ?> </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>
<?php if(count($datas) == 0): ?>
   <tr><p class="text-center p-5">No Data Found</p></tr>
<?php endif; ?>


<?php $paginate = $datas ?>
<?php echo $__env->make( 'backend.partials.pagination', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\xampp\htdocs\Laravel10-inventory-version-php8.2.2\resources\views/backend/components/invoice/table.blade.php ENDPATH**/ ?>