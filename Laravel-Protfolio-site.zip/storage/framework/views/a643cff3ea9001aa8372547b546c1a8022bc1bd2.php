

<table id="example" class="table table-striped table-bordered" style="width:100%">
  <thead>
    <tr>
      <th>Sl</th>
      <th>Purhase No</th>
      <th>Date </th>
      <th>Supplier</th>
      <th>Category</th>
      <th>Brand</th>
      <th>Qty</th>
      <th>Product Name</th>
      <th>Product Image</th>
      <th>Status</th>
      <th>Action</th>
    </tr>
  </thead>
  <tbody>
    <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td> <?php echo e($key+1); ?> </td>
        <td> <?php echo e($item->purchase_no); ?> </td>
        <td> <?php echo e(date('d-m-Y',strtotime($item->date))); ?> </td>
        <td> <?php echo e($item['supplier']['name']); ?> </td>
        <td> <?php echo e($item['category']['name']); ?> </td>
        <td> <?php echo e($item['brand']['name']); ?> </td>
        <td> <?php echo e($item->buying_qty); ?> </td>
        <td> <?php echo e($item['product']['name']); ?> </td>
        <td> <img src="<?php echo e(asset( $item['product']['image'] )); ?>" style="width:60px; height:50px"></td>
        <td>
          <?php if($item->status == '0'): ?><span class="btn btn-warning">Pending</span>
          <?php elseif($item->status == '1'): ?><span class="btn btn-success">Approved</span><?php endif; ?>
        </td>
        <td>
          <div class="col">
            <?php if($item->status == '0'): ?>
                <button type="button" class="btn btn-outline-danger btn-sm delete_row" id_val="<?php echo e($item->id); ?>" ><i class="lni lni-trash"></i></button>
            <?php endif; ?>
          </div>
        </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>
<?php if(count($datas) == 0): ?>
   <tr><p class="text-center p-5">No Data Found</p></tr>
<?php endif; ?>


<?php $paginate = $datas ?>
<?php echo $__env->make( 'backend.partials.pagination', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\xampp\htdocs\lb-inventory\resources\views/backend/components/purchase/table.blade.php ENDPATH**/ ?>