<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB,Auth;
class SettingController extends Controller
{
    //


    public function GetSetting()
    {
        return view('backend.pages.setting.index');
    }



    public function SettingHeader(Request $request)
    {
       DB::table('users')->where('id',Auth::user()->id)->update([
        'header_color'=>$request->bg,
      ]);
    }

    public function SettingSideber(Request $request)
    {
       DB::table('users')->where('id',Auth::user()->id)->update([
        'sideber_color'=>$request->bg,
      ]);
    }



    public function updateSetting(Request $request)
    {
      $dd =DB::table('settings')->first();
        $data = array();
        if ($request->file('logo_img')) {
            $file = $request->file('logo_img');
            @unlink(public_path('images/setting/'.$dd->logo));
            $filename = date('YmdHi').$file->getClientOriginalName();
            $file->move(public_path('images/setting/'),$filename);
            $data['logo'] = $filename;
        }
        if ($request->file('favicon')) {
            $file = $request->file('favicon');
            @unlink(public_path('images/setting/'.$dd->favicon));
            $filename = date('YmdHi').$file->getClientOriginalName();
            $file->move(public_path('images/setting/'),$filename);
            $data['favicon'] = $filename;
        }
        $data['email'] = $request->email;
        $data['phone'] = $request->phone;
        $data['title'] = $request->title;
        $data['s_title'] = $request->s_title;
        $data['s_desc'] = $request->s_desc;
        $data['a_title'] = $request->a_title;
        $data['sk_title'] = $request->sk_title;
        $data['sk_desc'] = $request->sk_desc;
        $data['p_title'] = $request->p_title;
        $data['p_desc'] = $request->p_desc;
        DB::table('settings')->update($data);
        $notification = array('message' => 'Update Success!','alert-type' => 'success');
        return redirect()->back()->with($notification);
    }





}
