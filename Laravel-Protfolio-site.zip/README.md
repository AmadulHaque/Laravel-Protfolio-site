# Laravel10-inventory-version-php8.2.2
 Laravel10-inventory-version-php8.2.2
